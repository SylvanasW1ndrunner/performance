# db_init.py (初始化数据库)
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
